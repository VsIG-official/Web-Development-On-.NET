﻿роутинг по умолчанию:
/Home/Index/

возможные запросы:
GET /Home/Index ->  GET /Home/Buy/Id bootstrap, jQuery dialogs, jQuery-button_up
GET /Home/Search ->  автозаполнение с jQuery UI, ajax-запрос
GET /Home/IndexPaged - PagedList.MVC

GET /Home/CreateBook - создать модель
GET /Home/EditBook/Id - редактировать модель
GET /Home/DeleteBook/Id - удалить модель